//모듈 사용
const mongoose = require('mongoose');

// 사용자 스키마 정의
const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true }, // 데이터 : 문자열, 필수 입력 필드, 사용자 이름의 유일성 보장
    password: { type: String, required: true }, // 데이터 : 문자열, 필수 입력 필드
    memberLevel: { // 데이터 : 문자열, 필수 입력 필드, 해당 필드의 가능한 값들
        type: String, 
        required: true, 
        enum: ['재학생', '입시생', '졸업생'], 
        default: '입시생' // 기본 값 설정
    }
});

// User 모델 생성
const User = mongoose.model('User', UserSchema);
// User 모델 내보내기
module.exports = User;
