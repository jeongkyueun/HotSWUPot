$(document).ready(async function () {
    // Top 버튼 클릭 시 맨 위로 올라가기
    $('.topButton').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 100);
    });

    // 로컬 스토리지에서 토큰 가져오기 (로그인된 상태인지)
    const token = localStorage.getItem('token');
    // 네비게이션 바의 '로그인' 부분 선택
    const authLink = $('#authLink');

    // 로그인 상태에 따라 '로그인' 부분 텍스트와 클릭시 이벤트 설정
    function updateAuthLink() {
        if (token) {
            // 토큰이 true(있으)면 '로그아웃' 버튼으로 업데이트하고 클릭 이벤트 설정 (로그인된 상태)
            authLink.text('로그아웃').attr('href', '#').off('click').on('click', function (event) {
                event.preventDefault(); // 기본 동작 막기
                logout(); // 로그아웃 함수 호출
            });
        } else {
            // 토큰이 false(없으)면 '로그인' 버튼으로 업데이트 (로그인 안된 상태)
            authLink.text('로그인').attr('href', '../login/login.html');
        }
    }
    // 로그아웃 함수
    async function logout() {
        localStorage.removeItem('token'); // 로컬 스토리지에서 토큰 제거
        window.location.href = '../login/login.html'; // 로그인 페이지로 리다이렉트
    }

    // 페이지 로드 시 로그인 상태에 따라 '로그인' 부분 업데이트
    updateAuthLink();

    // 각 버튼 클릭 시 내용 변경 기능
    $('#first').on('click', function () {
        $('#first').css("color", "#FFFFFF");
        $('#second, #third, #fourth').css("color", "#6D6E72");
        $('#subject1').html('<li>C++ 프로그래밍기초</li><li>소프트웨어융합진로탐색 I</li>');
        $('#subject2').html('<li>소프트웨어개론</li><li>컴퓨터수학</li>');
        $('#subject3').html('<li>-</li>');
        $('#subject4').html('<li>C++ 프로그래밍응용</li><li>웹디자인및기획</li><li>소프트웨어개발실무영어 I</li><li>확률과통계</li>');
    });
    $('#second').on('click', function () {
        $('#second').css("color", "#FFFFFF");
        $('#first, #third, #fourth').css("color", "#6D6E72");
        $('#subject1').html('<li>자료구조</li>');
        $('#subject2').html('<li>JAVA프로그래밍기초</li><li>웹표준언어</li>');
        $('#subject3').html('<li>-</li>');
        $('#subject4').html('<li>컴퓨터구조</li><li>컴퓨터알고리즘</li><li>운영체제</li><li>JAVA프로그래밍응용</li><li>빅데이터수집및마이닝</li><li>컴퓨터비전</li>');
    });

    $('#third').on('click', function () {
        $('#third').css("color", "#FFFFFF");
        $('#first, #second, #fourth').css("color", "#6D6E72");
        $('#subject1').html('<li>-</li>');
        $('#subject2').html('<li>컴퓨터그래픽스</li><li>영상처리</li><li>윈도우프로그래밍</li><li>데이터베이스기초</li><li>DIY종합설계프로그래밍</li><li>소프트웨어개발실무영어 II</li>');
        $('#subject3').html('<li>소프트웨어융합진로탐색 II</li>');
        $('#subject4').html('<li>데이터통신및네트워크</li><li>웹프로그래밍</li><li>데이터베이스응용</li><li>모바일프로그래밍</li><li>클라우드오픈소스소프트웨어</li><li>인공지능</li>');
    });

    $('#fourth').on('click', function () {
        $('#fourth').css("color", "#FFFFFF");
        $('#first, #second, #third').css("color", "#6D6E72");
        $('#subject1').html('<li>프로젝트종합설계 I</li><li>소프트웨어역량인증</li>');
        $('#subject2').html('<li>유닉스프로그래밍</li><li>기계학습</li><li>빅데이터분석</li>');
        $('#subject3').html('<li>소프트웨어역량인증</li><li>프로젝트종합설계 II</li>');
        $('#subject4').html('<li>소프트웨어와스타트업</li><li>VR/AR/MR프로그래밍</li><li>딥러닝및응용</li>');
    });
});

//(주아)마이페이지 버튼 클릭시 작동할 함수 
function handleMyPage() {
    fetch('/myPage', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (response.status === 401) {
            alert('로그인이 필요합니다. 로그인 후 이용해주세요.');
        } else if (response.ok) {
            window.location.href= '/myPage';
        } else {
            alert('서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.');
    });
}