$(document).ready(function () {
    //(나영초 코드 작성 시작)
    // 네비게이션 바의 '로그인' 부분 선택
    const authLink = $('#authLink');

    // 로그인 상태에 따라 '로그인' 부분 텍스트와 클릭시 이벤트 설정
    function updateAuthLink() {
        // 로컬 스토리지에서 토큰 가져오기 (로그인된 상태인지)
        const token = localStorage.getItem('token'); 

        if (token) {
            // 토큰이 true(있으)면 '로그아웃' 버튼으로 업데이트하고 클릭 이벤트 설정 (로그인된 상태)
            authLink.text('로그아웃').attr('href', '#').off('click').on('click', function (event) {
                event.preventDefault(); // 기본 동작 막기
                logout(); // 로그아웃 함수 호출
            });
        } else {
            // 토큰이 false(없으)면 '로그인' 버튼으로 업데이트 (로그인 안된 상태)
            authLink.text('로그인').attr('href', '#');
        }
    }

    // 로그아웃 함수
    function logout() {
        localStorage.removeItem('token'); // 로컬 스토리지에서 토큰 제거
        window.location.href = '#'; // 로그인 페이지로 리다이렉트
    }

    // 페이지 로드 시 로그인 상태에 따라 '로그인' 부분 업데이트
    updateAuthLink();

    // 로그인 폼 제출
    $('#loginForm').submit(async function (event) {
        event.preventDefault(); // 기본 제출 동작 막기

        // 입력된 닉네임(id)과 비밀번호 가져오기
        const username = $('#username').val();
        const password = $('#password').val();

        try {
            // 로그인 요청을 서버에 전송
            const response = await fetch('/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password }) // 요청 본문에 사용자 정보 포함
            });

            if (response.ok) {
                // 로그인 성공 시 응답에서 토큰 가져오고, 후 로컬 스토리지에 저장
                const data = await response.json();
                localStorage.setItem('token', data.token);
                window.location.href = '../myPage'; // 마이페이지로 리다이렉트
            } else {
                // 로그인 실패 시 오류 메시지 표시
                const errorText = await response.text();
                alert(`로그인 실패: ${errorText}`);
            }
        } catch (error) {
            // 로그인 요청 중 오류 발생 시 오류 로그와 사용자에게 알림
            console.error('로그인 요청 중 오류 발생:', error);
            alert('로그인 요청 중 오류가 발생했습니다.');
        }
    });

    // 입력창의 초기값 처리
    $('.id').focus(function () {
        // 아이디 입력창에 포커스 시 '아이디'라는 기본값을 지움
        if ($(this).val() === '아이디') {
            $(this).val('');
        }
    }).blur(function () {
        // 아이디 입력창에서 포커스가 사라지고 값이 없으면 '아이디'라는 기본값으로 복원
        if ($(this).val() === '') {
            $(this).val('아이디');
        }
    });

    $('.password').focus(function () {
        // 비밀번호 입력창에 포커스 시 'password'라는 기본값을 지움
        if ($(this).val() === 'password') {
            $(this).val('');
        }
    }).blur(function () {
        // 비밀번호 입력창에서 포커스가 사라지고 값이 없으면 'password'라는 기본값으로 복원
        if ($(this).val() === '') {
            $(this).val('password');
        }
    });
    //(나영초 코드 작성 끝)
});
