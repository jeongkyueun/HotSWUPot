//게시판 내용 입력하기의 카테고리 선택
function updateCategory(category) {
    
    // 찾은 요소의 텍스트 내용을 전달받은 'category' 값으로 설정
    document.getElementById('experienceDropdown').innerText = category;
    document.getElementById('category-name').value = category;
};

$(document).ready(async function () {
    // Top 버튼 클릭 시 맨 위로 올라가기
    $('.topButton').click(function() {
        $('html, body').animate({ scrollTop: 0 }, 100);
    });

    // 로컬 스토리지에서 토큰 가져오기 (로그인된 상태인지)
    const token = localStorage.getItem('token');
    // 네비게이션 바의 '로그인' 부분 선택
    const authLink = $('#authLink');

    // 로그인 상태에 따라 '로그인' 부분 텍스트와 클릭시 이벤트 설정
    function updateAuthLink() {
        if (token) {
            // 토큰이 true(있으)면 '로그아웃' 버튼으로 업데이트하고 클릭 이벤트 설정 (로그인된 상태)
            authLink.text('로그아웃').attr('href', '#').off('click').on('click', function (event) {
                event.preventDefault(); // 기본 동작 막기
                logout(); // 로그아웃 함수 호출
            });
        } else {
            // 토큰이 false(없으)면 '로그인' 버튼으로 업데이트 (로그인 안된 상태)
            authLink.text('로그인').attr('href', '../../login/login.html');
        }
    }
});


//게시글 개수 변수(주아)
var postCount = parseInt(localStorage.getItem('postCount')) || 0;
//게시글 저장 기능(주아)
document.getElementById('writing-form').addEventListener('submit', async function (event) {
    event.preventDefault();
    //유저 아이디 추출하기 위해 토큰 추출
    const token = localStorage.getItem('token');
    const response = await fetch('/users/me', {
        headers: {
            'Authorization': `Bearer ${token}` // 인증 헤더 추가
        }
    });
    const user = await response.json();
    const userId = user._id;

    const formData = new FormData(document.getElementById('writing-form'));
    formData.append('userId', userId);

    try {

        const response = await fetch('/savePosts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Bearer ${token}`
            },
            body: new URLSearchParams(formData)
        });

        const result = await response.text();
        if (response.ok) {
            postCount += 1;
            localStorage.setItem('postCount', postCount);
            alert('등록 완료');
            alert(`현재까지 작성한 모든 게시글 수: ${postCount}`);
            window.location.href = '/experienceBoard/list';
        } else {
            alert(result);
        }
    } catch (error) {
        console.error('Error:', error);
    }
});
//(주아)마이페이지 버튼 클릭시 실행할 함수
function handleMyPage() {
    fetch('/myPage', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (response.status === 401) {
            alert('로그인이 필요합니다. 로그인 후 이용해주세요.');
        } else if (response.ok) {
            window.location.href= '/myPage';
        } else {
            alert('서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.');
    });
}