
$(document).ready(async function () {

    $('.topButton').click(function () { //Top버튼 클릭시
        $('html, body').animate({ scrollTop: 0 }, 100); //맨 위로 올라가기
    });

    // 로컬 스토리지에서 토큰 가져오기 (로그인된 상태인지)
    const token = localStorage.getItem('token');
    // 네비게이션 바의 '로그인' 부분 선택
    const authLink = $('#authLink');

    // 로그인 상태에 따라 '로그인' 부분 텍스트와 클릭시 이벤트 설정
    function updateAuthLink() {
        if (token) {
            // 토큰이 true(있으)면 '로그아웃' 버튼으로 업데이트하고 클릭 이벤트 설정 (로그인된 상태)
            authLink.text('로그아웃').attr('href', '#').off('click').on('click', function (event) {
                event.preventDefault(); // 기본 동작 막기
                logout(); // 로그아웃 함수 호출
            });
        } else {
            // 토큰이 false(없으)면 '로그인' 버튼으로 업데이트 (로그인 안된 상태)
            authLink.text('로그인').attr('href', '../../login/login.html');
        }
    }
    // 로그아웃 함수
    async function logout() {
        localStorage.removeItem('token'); // 로컬 스토리지에서 토큰 제거
        window.location.href = '../../login/login.html'; // 로그인 페이지로 리다이렉트
    }

    // 페이지 로드 시 로그인 상태에 따라 '로그인' 부분 업데이트
    updateAuthLink();
});

//(주아)게시글 삭제하기 위한 기능 구현
var postCount = parseInt(localStorage.getItem('postCount'));
async function deletePost(postId) {
    if (confirm('정말로 이 게시글을 삭제하시겠습니까?')) {
        try {
            const response = await fetch(`/deletePost/${postId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json'
                }
            });
            const message = await response.text();
            if (response.ok) {
                alert(message);
                postCount-=1;
                alert(`삭제가 완료되었습니다.`);
                window.location.href='/experienceBoard/list';
            } else {
                alert(message);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('서버오류');
        }
        
    }
}

async function editPost(postId) {

    try {
        const response = await fetch(`/edit/${postId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            }
        });
    
        if (response.ok) {
            window.location.href = `/edit/${postId}`;
        } else {
            const message = await response.text();
            alert(message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('서버오류');
    }
}
    
//(주아)마이페이지 버튼 클릭시 실행할 함수
function handleMyPage() {
    fetch('/myPage', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (response.status === 401) {
            alert('로그인이 필요합니다. 로그인 후 이용해주세요.');
        } else if (response.ok) {
            window.location.href= '/myPage';
        } else {
            alert('서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.');
    });
}