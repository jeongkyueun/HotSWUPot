$(document).ready(async function () {
    
    // 전체 선택 체크박스 클릭 시 모든 체크박스의 체크 상태 변경
    $('.totalCheckBoxStyle').click(function () {
        $('.checkBoxStyle').prop('checked', this.checked);
    });

    // TOP버튼 기능(상단으로 올라가기)
    $('.topButton').click(function() {
        $('html, body').animate({ scrollTop: 0 }, 100);
    });

    // 로컬 스토리지에서 토큰 가져오기 (로그인된 상태인지)
    const token = localStorage.getItem('token');
    if (token) {
        try {//로그인된 상태
            // 사용자 정보 요청
            const response = await fetch('/users/me', {
                headers: {
                    'Authorization': `Bearer ${token}` // 인증 헤더 추가
                }
            });
            
            if (response.ok) {
                // 사용자 정보가 성공적으로 반환된 경우
                const user = await response.json();
                $('.profileId').text(user.username); // 사용자 이름 나타내기
                $('.profileRank').text(user.memberLevel); // 사용자 회원 등급 나타내기
            } else if (response.status === 401) {
                // 오류 발생 시 토큰 갱신 시도
                const newToken = await refreshToken(token);
                if (newToken) {
                    // 새 토큰을 로컬 스토리지에 저장하고 페이지 새로 고침
                    localStorage.setItem('token', newToken);
                    location.reload();
                } else {
                    // 토큰 갱신 실패 시 로그인 페이지로 리다이렉트
                    window.location.href = '../login/login.html';
                }
            } else {
                // 사용자 정보를 가져오지 못한 경우 오류 메시지 표시
                alert('사용자 정보를 가져오지 못했습니다.');
            }
        } catch (error) {
            // 사용자 정보를 가져오는 도중 오류 발생 시 로그와 알림
            console.log('오류:', error);
            alert('사용자 정보를 가져오는 도중 오류가 발생했습니다.');
        }
    } else {
        // 토큰이 없는 경우 로그인 페이지로 리다이렉트(로그인이 안된 경우)
        window.location.href = '../login/login.html';
    }

    // 페이지 로드 시 로그인 상태에 따라 '로그인' 부분 업데이트
    updateAuthLink();
});

// 기존 토큰을 사용하여 새 토큰 요청
async function refreshToken(oldToken) {
    try {
        const response = await fetch('/auth/refresh', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ token: oldToken }) // 요청 본문에 기존 토큰 포함
        });

        if (response.ok) {
            // 새 토큰 반환 시 반환
            const data = await response.json();
            return data.token;
        } else {
            // 새 토큰 요청 실패 시 null 반환
            return null;
        }
    } catch (error) {
        // 토큰 갱신 요청 중 오류 발생 시 로그
        console.log('토큰 갱신 오류:', error);
        return null;
    }
}

 // 로그인 상태에 따라 '로그인' 부분 텍스트와 클릭시 이벤트 설정
function updateAuthLink() {
    // 네비게이션 바의 '로그인' 부분 선택
    const authLink = $('#authLink');
    // 로컬 스토리지에서 토큰 가져오기 (로그인된 상태인지)
    const token = localStorage.getItem('token');

    if (token) {
        // 토큰이 true(있으)면 '로그아웃' 버튼으로 업데이트하고 클릭 이벤트 설정 (로그인된 상태)
        authLink.text('로그아웃').attr('href', '#').off('click').on('click', function (event) {
            event.preventDefault(); // 기본 동작 막기
            logout(); // 로그아웃 함수 호출
        });
    } else {
        // 토큰이 false(없으)면 '로그인' 버튼으로 업데이트 (로그인 안된 상태)
        authLink.text('로그인').attr('href', '../login/login.html');
    }
}

// 로그아웃 함수
function logout() {
    localStorage.removeItem('token'); // 로컬 스토리지에서 토큰 제거
    window.location.href = '../login/login.html'; // 로그인 페이지로 리다이렉트
}

// (영초) : 마이페이지에서 게시글 삭제
async function deleteSelectedPosts() {
    // 체크된 모든 체크박스를 찾기
    const checkboxes = document.querySelectorAll('.checkBoxStyle:checked');

    if (checkboxes.length === 0) {
        alert('삭제할 게시글을 선택해주세요.');
        return;
    }

    const confirmed = confirm('정말로 선택한 게시글들을 삭제하시겠습니까?');
    if (!confirmed) {
        return;
    }

    let deletedCount = 0;

    for (const checkbox of checkboxes) {
        const postId = checkbox.getAttribute('data-post-id');
        try {
            const response = await fetch(`/deletePost/${postId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json'
                }
            });

            const message = await response.text();

            if (response.ok) {
                deletedCount++;
                // 각 게시글이 성공적으로 삭제된 경우 UI에서 해당 게시글을 제거
                checkbox.closest('.boardDocOne').remove();
            } else {
                alert(`게시글 삭제 실패: ${message}`);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('서버 오류');
        }
    }

    // 로컬스토리지에서 게시글 카운트를 갱신
    if (deletedCount > 0) {
        postCount -= deletedCount;
        localStorage.setItem('postCount', postCount);
        alert(`삭제된 게시글 수: ${deletedCount}\n남은 게시글 수: ${postCount}`);
        window.location.href = '/experienceBoard/list';
    }
}
