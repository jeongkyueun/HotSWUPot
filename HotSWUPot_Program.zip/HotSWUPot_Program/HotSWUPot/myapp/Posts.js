//주아 시작
const mongoose = require('mongoose');
//게시물 작성 스키마 설정
const Schema = mongoose.Schema;
const PostSchema = new Schema({
    category: {
        type: String,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    content: {
        type: String,
        required: true
    },
    author: {
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User', 
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

const Post = mongoose.model('Post', PostSchema);
module.exports = Post;

/*
const posts = [];

module.exports = class Post {
    constructor() {

    }

    save() {

    }

    static  fetchAll() {
        return this.posts;
    }
}
    */