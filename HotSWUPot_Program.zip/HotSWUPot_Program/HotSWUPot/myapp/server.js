//모듈 사용 (김희재)
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');
const User = require('./Users');
const app = express();
const port = 5025;
//게시물 저장을 위한 추가 모듈 (주아)
const Post = require('./Posts');

const session = require('express-session');

app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }  
}));

//템플릿엔진 연결(주아)
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));


// MongoDB 연결 (김희재)
mongoose.connect('mongodb://localhost:27017/myapp', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected...'))
    .catch(err => console.log(err));

// 미들웨어 설정(김희재)
app.use(bodyParser.urlencoded({ extended: true })); // URL-encoded 데이터를 파싱
app.use(bodyParser.json()); // JSON 데이터를 파싱
app.use(express.static(path.join(__dirname, 'public'))); // 'public' 폴더를 정적 파일 서빙

// 사용자 회원가입 라우트(김희재)
app.post('/signup', async (req, res) => {
    try {
        const { username, password, confirmPassword, memberLevel } = req.body;
        
        // 요청 본문 로그 출력 (디버깅용)
        console.log(req.body);

        // 모든 회원정보 부분 입력 확인
        if (!username || !password || !confirmPassword || !memberLevel) {
            return res.status(400).send('모든 회원정보 부분을 입력해주세요.');
        }

        // 기존 사용자 확인
        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(400).send('이미 존재하는 아이디입니다.');
        }

        // 비밀번호 일치 확인
        if (password !== confirmPassword) {
            return res.status(400).send('비밀번호가 일치하지 않습니다.');
        }

        // 비밀번호 해싱
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // 새로운 사용자 생성
        const newUser = new User({
            username,
            password: hashedPassword,
            memberLevel
        });

        // 사용자 저장
        await newUser.save();
        res.status(201).send('회원가입 성공!');
    } catch (error) {
        console.error(error); // 서버 오류 로그
        res.status(500).send('서버 오류가 발생했습니다.');
    }
});

// 로그인 라우트(나영초)
app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        // 모든 입력 부분 확인
        if (!username || !password) {
            return res.status(400).send('아이디와 비밀번호를 입력해주세요.');
        }

        // 사용자 확인
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(400).send('사용자를 찾을 수 없습니다.');
        }
        req.session.user = user;

        // 비밀번호 비교
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).send('비밀번호가 일치하지 않습니다.');
        }

        // JWT 토큰 생성
        // 페이로드: 사용자 ID (토큰에 포함될 데이터), 비밀 키: 토큰 서명을 위한 비밀 문자열, 토큰 만료 시간 (1시간 후 만료)
        const token = jwt.sign({ id: user._id }, 'your_jwt_secret', { expiresIn: '1h' }); 
        res.status(200).json({ token });
    } catch (error) {
        console.error(error); // 서버 오류 로그
        res.status(500).send('서버 오류가 발생했습니다.');
    }
});

// 사용자 정보 가져오기 라우트(나영초)
app.get('/users/me', async (req, res) => {
    try {
        // Authorization 헤더에서 토큰 추출
        const token = req.headers['authorization'].split(' ')[1];
        const decoded = jwt.verify(token, 'your_jwt_secret'); // 토큰 검증

        // 사용자 정보 조회 (비밀번호 제외)
        const user = await User.findById(decoded.id).select('-password');
        if (!user) { //사용자가 없으면
            return res.status(404).send('사용자를 찾을 수 없습니다.');
        }
        res.status(200).json(user);
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            // 토큰 만료 오류 처리
            return res.status(401).send('토큰이 만료되었습니다.');
        }
        console.error(error); // 서버 오류 로그
        res.status(500).send('서버 오류가 발생했습니다.');
    }
});

//(주아)게시글 저장
app.post('/savePosts', async (req, res) => {
    try {
        const { category, title, content, userId } = req.body;
        console.log(req.body);

        if (!category || !title || !content) {
            return res.status(400).send('제대로 입력하였는지 확인해주세요(카테고리, 제목, 내용)');
        } 

        const newPost = new Post({
            category,
            title,
            content,
            author: userId
        });

        await newPost.save();
        res.status(201).send('게시글 저장 성공');
    } catch (error) {
        console.error(error);
        res.status(500).send('서버 오류가 발생했습니다.');
    }
});

//(주아)게시글 목록 보기
app.get('/experienceBoard/list', async (req, res, next) => {
    try {
        const posts = await Post.find({});

        res.render('list', { posts: posts });
    } catch (error) {
        console.error(error);
        res.status(500).send('서버 오류가 발생했습니다');
    }
});

//(주아)게시물 상세 보기
app.get('/show/:id', async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);
        const user = await User.findById(post.author);
        if(!post) {
            return res.status(404).send('Post not found');
        }
        res.render('show', { post: post, user: user});
    } catch (err) {
        res.status(500).send(err.message);
    }
});

//(주아)마이페이지 (사용자별 게시글 보기)
app.get('/myPage', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.status(401).send('Unauthroized');
        }
        const user = req.session.user;

        const posts = await Post.find({ author: user._id });

        res.render('myPage', { posts: posts, user: user });
    } catch (error) {
        
        console.error(error);
        res.status(500).send('서버 오류가 발생했습니다.');
    }
});

//(주아)게시글 삭제기능 구현
app.delete('/deletePost/:id', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.status(401).send('로그인을 먼저 하세요.');
        }

        const postId = req.params.id;
        const userId = req.session.user._id;

        const post = await Post.findById(postId);

        if (!post) {
            return res.status(404).send('Post not found.');
        }

        if (post.author.toString() !== userId.toString()) {
            return res.status(403).send('권한이 없습니다.');
        }

        await post.deleteOne();
        res.status(200).send('삭제되었습니다.');
    } catch (error) {
        console.error(error);
        res.status(500).send('오류가 발생했습니다.');
    }
});

app.get('/edit/:id', async(req, res) => {
    try {
        if (!req.session.user) {
            return res.status(401).send('로그인을 먼저 하세요.');
        }
        const postId = req.params.id;
        const userId = req.session.user._id;
        const post = await Post.findById(postId);

        if (post.author.toString() !== userId.toString()) {
            return res.status(403).send('권한이 없습니다.'); //로그인된 유저가 게시글 작성자가 아닐시
        }
        

        res.render('postEdit' , {post: post});
    } catch (error) {
        console.error(error);
        res.status(500).send('서버 오류가 발생했습니다.');
    }
    
});

app.post('/edit/:id', async (req, res) => {
    const { title, content, category, postId } = req.body;
    console.log('Post ID from body:', postId);

    try {        
        const post = await Post.findById(postId);
        await post.updateOne({ $set: { category: category, title: title, content: content} } );
        
        res.redirect('/experienceBoard/list');
    } catch (error) {
        console.error(error);
        res.status(500).send('서버 오류가 발생했습니다.');
    }
});

// 서버 시작
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});


