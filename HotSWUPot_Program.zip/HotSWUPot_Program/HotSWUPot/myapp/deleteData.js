const mongoose = require('mongoose');
const User = require('./Users'); // User 모델 경로를 설정하세요

mongoose.connect('mongodb://localhost:27017/myapp', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(async () => {
        console.log('MongoDB connected...');
        
        // 모든 사용자 삭제
        await User.deleteMany({});
        console.log('모든 사용자 데이터가 삭제되었습니다.');

        mongoose.disconnect();
    })
    .catch(err => console.log(err));
